/*Dummy file to satisfy source file dependencies on Windows platform*/
#define strcasecmp _stricmp
#define strncasecmp _strnicmp
#define inline __inline
